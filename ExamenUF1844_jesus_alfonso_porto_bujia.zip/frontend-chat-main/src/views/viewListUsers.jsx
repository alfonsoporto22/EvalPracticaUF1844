import GetLogin from "../components/GetLogin/GetLogin"

function viewLogin() {
    return (
        <GetLogin />
    )
}

export default viewLogin