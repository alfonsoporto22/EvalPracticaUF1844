import GetLogin from "../components/GetLogin/GetLogin"
import Login from "../components/Login/Login"
import './style/viewLogin.css';

function viewLogin() {
    return (
        <div className="login">
            <Login />
        </div>
    )
}

export default viewLogin