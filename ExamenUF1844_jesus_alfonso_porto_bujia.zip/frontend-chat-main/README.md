# Aplicación de mensajería

Aplicación web realizada de cara al examen práctico del Módulo:MF0492_3-UF1844, con las siguientes finalidades: Creación de una cuenta de usuario, obtención de la lista de usuarios existentes,
visualización y envío de nuevos mensajes a la API.

El usuario se dará de alta a través de Login. Se registrará en la aplicación a través de Registro
usando el id del usuario y la contraseña. Una vez registrado podrá ver y enviar mensajes a la 
API. 